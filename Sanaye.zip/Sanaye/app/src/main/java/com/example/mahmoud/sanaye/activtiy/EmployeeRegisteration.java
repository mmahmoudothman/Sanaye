package com.example.mahmoud.sanaye.activtiy;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.mahmoud.sanaye.R;

public class EmployeeRegisteration extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_employee_registeration);
    }
}
