package com.example.mahmoud.sanaye;

public class Constants {


    public static String phoneNumber;
    public static boolean isLoged = false;
    public static boolean type = false;


    /// shardPref
    public static String SHARDPREFNAME="SHARDPREFNAME";
    public static String NAME="NAME";
    public static String PHONE="PHONE";
    public static String JOB="JOB";
    public static String LOCATION="LOCATION";


}
