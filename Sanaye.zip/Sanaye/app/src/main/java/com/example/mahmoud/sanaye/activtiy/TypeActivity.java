package com.example.mahmoud.sanaye.activtiy;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.LinearLayout;

import com.example.mahmoud.sanaye.Constants;
import com.example.mahmoud.sanaye.R;
import com.example.mahmoud.sanaye.activtiy.user.SelectAtivity;

public class TypeActivity extends AppCompatActivity {

    LinearLayout btnUser, btnEmployee;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_type);


        btnUser = findViewById(R.id.loginLay);
        btnEmployee = findViewById(R.id.btn_employee);
        Constants.isLoged = true;

    }


    public void employeeAction(View view) {
        Constants.type = true;
        Intent employeeIntent = new Intent(TypeActivity.this, UserRegisteration.class);
        startActivity(employeeIntent);
    }

    public void userAction(View view) {
        Constants.type = false;
        Intent employeeIntent = new Intent(TypeActivity.this, SelectAtivity.class);
        startActivity(employeeIntent);
        finish();

    }
}
